<?php


/* edit.php
Permite editar un libro existente en la lista de libros
@pckage CRUD libros
@author Pablo Jiménez
@version 1.0


Tabla libros
    -id(INT, PRIMARY_KEY, AUTO_INCREMENT)
    -titulo(VARCHAR, 255, NOT NULL)
    -autor(VARCHAR, 255, NOT NULL)
    -editorial(VARCHAR, 100, NOT NULL)
    -generos
    -precios

    */

// cargar librerias
require_once "libs/fuctions.php";

// Models

//Negociado
// Otnener el indice del libro a editar desde la url
// edit.php?id=0 edito el primer libro
$indice = htmlspecialchars($_GET["id"] ?? '');

// Validar el indice

// Obtener el libro a editar cargando el array
$libro = getLibro($indice);

// Obtener el libro que voy a editar
$libro = $libros[$indice];

// Views
require_once "views/edit.view.php";